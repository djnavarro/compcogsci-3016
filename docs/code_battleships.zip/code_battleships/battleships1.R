# code the solution to the toy battleships problem 
# in the lecture slides. The code here is still 
# a bit inefficient, but I've started to make use of
# a few of Rs more useful data structures, and I've
# been fancier about the graphics. The comments draw
# attention to some R-specific concepts.


#################

# Each hypothesis is an Nx4 matrix, where N is the number of 
# rectangles, and the four columns specify the edges of the 
# rectangle, in the format c(LEFT,RIGHT,BOTTOM,TOP). We store
# the hypotheses as a list of matrices
hypotheses <- list( 
  
  rbind( c( 4,7,11,13 ) ), # one small rectangle
  rbind( c( 4,14,2,12) ), # one large rectangle
  rbind( c(4,5,12,13), 
         c(6,7,8,9), 
         c( 12,13,6,6), 
         c(14,15,2,2) ), # four small rectangles
  rbind( c(2,6,5,15), 
         c(10,15,13,15), 
         c( 9,12,3,10), 
         c(14,15,1,8) ) # four large rectangles
)

# Each observation is a vector of length 2, specifying the
# horizontal and vertical co-ordinates respectively. We'll
# "rowbind" a set of N vectors into an Nx2 matrix
data <- rbind( c(5,12), c(4,12), c(6,8), c(14,2) )

# other settings
exportImages <- FALSE  # export images to PNG if need be?
dir <- "~/Desktop/"  # where to save files if we do export them?

#################

# read off the number of hypotheses, the number of observations, and the
# number of rectangles within each hypothesis
nX <- dim(data)[1]  # number of observations?
nH <- length( hypotheses ) # number of hypotheses?
nR <- vector( length=nH ) # how many rectangles in each hypothesis?
for( i in 1:nH ) {
  nR[i] <- dim( hypotheses[[i]] )[1] # <-- the list is indexed with [[ ]]
}

# the prior probability of a hypothesis is inversely proportional 
# to the number of rectangles it consists of. This is our way of
# enforcing a simplicity bias
prior <- 1/nR 
prior <- prior / sum( prior )

# define a helper function to compute the size of a rectangle
rectSize <- function( r ) { # <-- functions in R must be defined before they are called!
  s <- (1+r[2]-r[1]) * (1+r[4]-r[3]) 
  return(s) 
}

# compute sizes
size <- rep.int(0,nH) # <-- a length nH vector containing all zeros
for( h in 1:nH ) { # loop across hypotheses
  for( r in 1:nR[h] ) { # loop across rectangles 
    thisRect <- hypotheses[[h]][r,] # <-- hypothesis[[h]] is a matrix, and so
                                    #     hypothesis[[h]][r,] is the r-th row
    size[r] <- size[r] + rectSize( thisRect ) 
  }
}

# define a function to check if an observation falls in a rectangle. Usually
# I'd define all my functions at the top of the script, but for the moment I'll
# just define them right before they're needed
pointInRectangle <- function( x, r ){
  
  if( # conditions
      x[1] >= r[1] &   # check the left edge of the rectangle
      x[1] <= r[2] &   # check the right edge of the rectangle
      x[2] >= r[3] &   # check the bottom edge of the rectangle
      x[2] <= r[4]     # check the top edge of the rectangle
  ){  
    return(TRUE) # yes, it falls in the rectangle
    
  } else {
    return(FALSE) # no, it doesn't
  }  
}


# keep track of our beliefs (i.e., priors and posteriors)
belief <- matrix( NA, nH, nX+1 )  # belief where each row is a hypothesis, and each column
                                  # refers to a time point (time 1 = prior, time 2 = posterior
                                  # after 1 observation, etc...)
belief[,1] <- prior # store the priors as the first column

for( i in 1:nX) { # loop across all possible observations
  obs <- data[i,] # the observation we're currently considering
  
  for( h in 1:nH ) { # loop over all possible hypotheses
    
    # check to see if the observation falls inside one of
    # the rectangles defined by this hypothesis
    inside <- 0
    for( r in 1:nR[h] ) {
      thisRect <- hypotheses[[h]][r,] # the r-th rectangle in the h-th hypothesis
      if( pointInRectangle( obs, thisRect ) ) { # does the observation fall inside it?
        inside <- 1 # if so, keep track of that fact
      }
    }
    
    # new degree of belief is found by taking the belief from the last time point and 
    # multiplying by the likelihood. The likelihood is 0 if the observation is outside
    # the rectangles, and 1/size[h] if it does fall inside one of the rectangles
    belief[h,i+1] <- belief[h,i] * inside / size[h]  
                       
  } 
  
  # enforce the law of conservation of belief (i.e., law of total probability). The 
  # degrees of belief must sum to 1
  belief[,i+1] <- belief[,i+1] / sum( belief[,i+1])
}

# this command grabs the current list of graphics PARameters. 
# we'll need them later because I'm going to change some of
# them and it's good manners to restore the graphics parameters
# to their original values at the end
op <- par( no.readonly=TRUE )

# plot each hypothesis against the data, and indicate the 
# degree of belief that the model has in each one. we'll 
# either plot them on screen, or else export the image to
# a PNG
for( b in 0:nX ) { # loop over all belief states
  
  if( exportImages ) {
    # settings for PNG export
    fname=paste0( dir,"rectanglePlot",i,".png")  # filename
    png( filename=fname, width=800, height=800 )  # create the new graphics "device" to draw to
    titleSize <- 2 # a setting I'll use later
    
  } else {
    # settings for on-screen display
    titleSize <- 1.25  # a setting I'll use later
    par( mar=c(2,2,4,2) + .1 ) # reset the margins to fit a bit better
  }
  
  displayMatrix <- matrix(1:4,2,2) # matrix of plotting areas, plus the order in which to draw them
  layout( displayMatrix ) # set the layout of the plotting area
  
  if( i>0 ) { 
    xx <- data[1:i,,drop=FALSE]
  } else {
    xx <- NULL
  }
  
  for( h in 1:nH ) {    
    
    thisHypothesis <- hypotheses[[h]] # grab the relevant hypothesis
    if( b>0 ) {
      thisData <- data[1:b,, drop=FALSE] # <-- the "drop=FALSE" part makes sure that even if only
                                         #     a single row is requested, the output stays as a 
                                         #     1x2 matrix, and doesn't get "dropped" to a vector
    }
                             
    # add a plot to the figure area
    plot.new() # create a new plot
    plot.window( xlim=c(1,16), ylim=c(1,16) ) # define the axis limits
    grid(16,16) # plot a 16x16 grid
    if( b>0 ) { # if there's data to plot...
      
      # draw little shaded boxes to indicate where the data were observed
      rect( thisData[,1]-.5, # left edges of the boxes
            thisData[,2]-.5, # bottom edges of the boxes
            thisData[,1]+.5, # right edges of the boxes
            thisData[,2]+.5, # top edges of the boxes
            density=10 # how tightly should we pack the shading lines?
          ) 
      
    }
    
    # add the rectangles specifying the hypothesis
    rect( thisHypothesis[,1]-.5, # left
          thisHypothesis[,3]-.5, # bottom
          thisHypothesis[,2]+.5, # right
          thisHypothesis[,4]+.5, # top
          lwd=3 ) # increase the line width
    
    # paste together a few things to produce the text for the title
    titleText <- paste0( "Probability: ", 
                         round(belief[i+1,h]*100,2), 
                         "%" )
    
    # now make the figure title
    title( main= titleText, 
           cex.main= titleSize ) 
    
    box() # draw a box around the figure
    
  }
  
  # now that we're finished drawing images, either write the image data
  # to a file, or if it's on screen, wait for the user to respond before
  # moving on to the next one
  if( exportImages ) {
    # close the graphics device to save the PNG file
    # if that's what we're doing
    dev.off()
    
  } else {
    # wait for the user before drawing the next plot
    readline( "hit return to see the next plot" )
    
  }
  
}

# be polite: reset the graphics parameters to their original versions
# (because we might have changed the margin settings)
par( op )



