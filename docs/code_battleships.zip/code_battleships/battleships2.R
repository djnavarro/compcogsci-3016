# code for the more sophisticated version of the battleships problem.
# the code is still pretty inefficient, but this time around it's 
# not for teaching reasons: I just haven't had the time to think about
# how to code this properly 

#################

# how big a grid?
gridSize <- 8

# data 
data <- cbind(
  x = c( 2,3,5,6,5,6,3 ),
  y = c( 2,1,4,4,7,6,6 )
)

#################

# number of observations
nD <- dim(data)[1]

# create all possible rectangles that fit in the grid
cat("computing all one-rectangle hypotheses...\n")
rectangles <- matrix( NA, gridSize^4, 4) # starts with too many rows
nR <- 0 # count the number of rectangles
for( l in 1:gridSize ) { # left
  for( r in l:gridSize ) { # right
    for( b in 1:gridSize ) { # bottom
      for( t in b:gridSize ) { # top
        nR <- nR+1
        rectangles[nR,] <- c(l,r,b,t) # store the rectangle
      }
    }
  }
}

# truncate matrix to the correct number of rows
rectangles <- rectangles[1:nR,]

# sizes for each rectangle
size <- vector( length=nR )
for( i in 1:nR ){
  size[i] <- (1+rectangles[i,2]-rectangles[i,1]) * (1+rectangles[i,4]-rectangles[i,3])
}

# matrix indicating which rectangles overlap. this is pretty wasteful computation here
cat("computing all two-rectangle hypotheses...\n")
disjoint <- matrix( FALSE, nR, nR ) # assume they overlap
for( i in 1:nR ) {
  # check the conditions for disjoint rectangles
  disjoint[i,] <-  rectangles[i,2] < rectangles[,1] | # right(i) < left
    rectangles[i,1] > rectangles[,2] |  # left(i) > right
    rectangles[i,4] < rectangles[,3] |  # top(i) < bottom
    rectangles[i,3] > rectangles[,4]    # bottom(i) > top
}

# hypothesis space of 1-rectangles & 2-rectangles
twoRectangles <- which(disjoint, arr.ind=TRUE) 
nP <- dim(twoRectangles)[1]

# clear memory wasting variables
rm(disjoint)


# initialise matrices storing the beliefs after each observation
belief1 <- matrix(NA, nR, nD+1) # beliefs for 1-rectangle hypotheses
belief2 <- matrix(NA, nP, nD+1) # beliefs for 2-rectangle hypotheses

# priors set so there's a weak prior bias to expect 1 rectangle
belief1[,1] <- 1/nR * (2/3) # total degree of belief for 1-rect = .67
belief2[,1] <- 1/nP * (1/3) # total degree of belief for 2-rect = .33

# sizes for the 2-rectangle solutions
size2 <- size[twoRectangles[,1]] + size[twoRectangles[,2]]

# define a function to check if an observation falls in a rectangle
matches <- function( h, x){
  
  if( x[1] >= h[1]) { # check the left edge of the rectangle
    if( x[1] <= h[2] ) { # check the right edge of the rectangle
      if( x[2] >= h[3] ) { # check the bottom edge of the rectangle
        if( x[2] <= h[4] ) { # # check the top edge of the rectangle
          return(TRUE)
        }
      }
    }
  }
  return(FALSE)
  
}


# a plotting function we'll use later
plotGrid <- function( grid, obs, post, titlePrefix ) {
  
  titleString <- paste0( titlePrefix, 
                         " Posterior = ", 
                         round(100*post),
                         "%" )
  gs <- dim(grid)[1]
  image( 1:gs, 1:gs, grid, 
         col=grey( seq(1,0,-.01)), 
         xlab="", ylab="", 
         main=titleString )
  
  lines( obs[,1], obs[,2], type="p", pch=19, col="white")
  grid(gs,gs,lwd=2)
  
#   -- old code I used to export image files --  
#   dev.print( device=postscript, file=paste0("~/Desktop/rectangle",titlePrefix,d,".eps"), 
#              width=6,height=6,horizontal=FALSE,onefile=FALSE,paper="special")
  
}


# loop to determine beliefs
for( d in 1:nD ) {
  
  cat("-- adding observation",d,"--\n")
  cat("updating beliefs...\n")
  
  # the d-th observation
  obs <- data[d,]
  
  # this is a little bit of code optimisation here. the "apply" function
  # is one of the tricks for vectorising your loops in R. What I could have
  # done is loop over all rows in the "rectangles" matrix, and use the "matches"
  # function to see if the observation falls in the rectangle. Rather than
  # explicitly loop, I've told R to "apply" the "matches" function to each row
  # (that's the 1, indicating which dimension to apply the function over). the 
  # last argument here tells R to feed "obs" into the matches function as an
  # additional argument x.
  M1 <- apply( rectangles, 1, matches, x=obs )
  
  # in order for a two-rectangle hypothesis to match, one of the two rectangles
  # needs to include the observation. 
  M2 <- M1[twoRectangles[,1]] | M1[twoRectangles[,2]] 
  
  # update beliefs for the 1-rectangle hypotheses
  belief1[,d+1] <- belief1[,d] # copy belief from before
  
  belief1[!M1,d+1] <- 0 # falsify hypotheses inconsistent with data
  belief1[M1,d+1] <- belief1[M1,d+1] / size[M1] # update the rest
  
  # update beliefs for the 2-rectangle hypotheses
  belief2[,d+1] <- belief2[,d] # copy belief from before
  belief2[!M2,d+1] <- 0 # falsify hypotheses inconsistent with data
  belief2[M2,d+1] <- belief2[M2,d+1] / size2[M2] # update the rest
  
  # enforce conservation of belief
  summed <- sum( belief2[,d+1] ) + sum( belief1[,d+1] )
  belief1[,d+1] <- belief1[,d+1] / summed
  belief2[,d+1] <- belief2[,d+1] / summed  
  
  grid1 <- matrix(0,gridSize,gridSize)
  grid2 <- matrix(0,gridSize,gridSize)
  
  # loop over all rectangles that contain the data points so far, and add
  # the relevant beliefs (this isn't efficient)
  cat("computing one-rectangle generalisations...\n")
  for( i in which(belief1[,d+1]>0)) {
    r <- rectangles[i,] # get the i-th rectangle
    grid1[ r[1]:r[2], r[3]:r[4] ] <- grid1[ r[1]:r[2], r[3]:r[4] ] + belief1[i,d+1] # add belief to the relevant locations
  }
  
  # draw the picture
  plotGrid( grid1, data[1:d,,drop=FALSE], sum(belief1[,d+1]), "One rectangle." )  
  
  # this is the biggest time-wasting step. looping over all two-rectangle hypotheses
  # that contain the data points observed so far, and incrementing the belief
  cat("computing two-rectangle generalisations...\n")
  for( i in which(belief2[,d+1]>0)) {
    r1 <- rectangles[twoRectangles[i,1],]
    r2 <- rectangles[twoRectangles[i,2],]
    grid2[ r1[1]:r1[2], r1[3]:r1[4] ] <- grid2[ r1[1]:r1[2], r1[3]:r1[4] ] + belief2[i,d+1]
    grid2[ r2[1]:r2[2], r2[3]:r2[4] ] <- grid2[ r2[1]:r2[2], r2[3]:r2[4] ] + belief2[i,d+1]
  }
  
  # draw the picture
  plotGrid( grid2, data[1:d,,drop=FALSE], sum(belief2[,d+1]), "Two rectangles." )

}



