

#######################  functions for specifying the test points #######################

# generate a 2D grid of test locations for the 
# running example
testGrid <- function(x=seq(0,1,.05), y=seq(0,1,.05)){
  nx <- length(x) # number of x values
  ny <- length(y) # number of y values
  grid <- matrix( nrow=nx*ny, ncol=2 ) # initialise list of points
  ind <- 0 # counter
  for( i in 1:nx ) { # loop over x values
    for( j in 1:ny ) { # loop over y values
      ind <- ind+1 # increment counter
      grid[ind,] <- c(x[i], y[j]) # add the corresponding point
    }
  }
  return(grid)
}

# This is just a horrible, horrible function. I got stuck with a 
# data structure that I wasn't super-happy with, and this is an 
# ugly way of converting it to a format that the contour function
# is happy with. Sorry,
gridify <- function( points, values ){ 
  tmp <- data.frame( cbind( points, values)  )
  names(tmp) <- c("x","y","FAKE")
  z <- reshape(data=tmp,direction="wide",timevar="x",idvar="y")
  y <- z[,1]
  z <- z[,-1]
  x <- as.numeric( gsub( pattern="^FAKE.", replacement="", names(z) ) ) 
  z <- t(as.matrix(z))
  return( list(x=x,y=y,z=z))
}

####################### plotting functions #######################

# Add an ellipse to the current plot to correspond to a
# bivariate Gaussian with mean mu and covariance matrix
# sigma. This code is adapted from:
# http://www.stat.wmich.edu/wang/561/codes/R/ellipse1.R
addEllipse <- function( mu, sigma, unit=1, ... ){
  
  e <- eigen(sigma)
  z <- seq(-1,1,length=101)
  x <- unit*sqrt(e$values[1])*z
  y <- unit*sqrt(e$values[2])*sqrt(1-z^2)
  x <- c(x, rev(x)[-1])
  y <- c(y, rev(-y)[-1])
  z <- mu + e$vectors %*% rbind(x,y)
  lines( z[1,], z[2,], ... )
  return( invisible(z) )
  
} 


# Plot a 2D test grid showing the labels inferred by the
# classifier, the training data, and a set of contours.
# Only works if there are two categories, 1 and 2
plot2dClassifications <- function( trainingPoints, trainingLabels, 
                                   testPoints, testLabels ) {
  
  # define the plot colours
  softColours <-  rgb( red=c(1,.6), green=c(.6,.6), blue=c(.6,1))
  hardColours <- c("grey80","red","blue")
  
  # set up the plot area
  plot.new( )
  plot.window( xlim=range( testPoints[,1] ), 
               ylim=range( testPoints[,2] ))
  
  # draw the test points, with colour indicating the predicted labels
  lines( x = testPoints[,1], y = testPoints[,2], 
         col = softColours[ round(testLabels) ],
         type="p", pch=19, cex=.25 )
  
  # draw the training points, with colour indicating the observed labels
  lines( x = trainingPoints[,1], y = trainingPoints[,2], 
         col = hardColours[trainingLabels+1],
         type="p", pch=19 )
  
  # reshape the (nx*ny) by 2 points into a matrix with corresponding vectors
  grid <- gridify( testPoints, testLabels )
  
  # contour
  contour( x=grid$x, y=grid$y, z=grid$z, levels=1.5, add=TRUE, drawlabels=FALSE )
  
  # add a box around the plot
  box()
  
}


# Plot a set of distributions/classifications for a 1D training set
plot1dClassifications <- function( trainingPoints, trainingLabels, 
                                   testPoints, testValues ){
  
  # handy values
  nTrain <- length( trainingPoints )
  nTest <- length( testPoints )
  nClass <- max( trainingLabels )
  
  # set up the plot area and colour palette
  plot.new()
  plot.window( xlim=range(testPoints), ylim=c(0,max(testValues)) )
  colours <- rainbow( nClass )
  
  # draw the curves for each class
  for( i in 1:nClass ){
    lines( testPoints, testValues[,i], type="l", lwd=2, col=colours[i] )
  }
  
  # plot the training data for each class
  for( i in 1:nClass ){
    points <- trainingPoints[ trainingLabels==i ] 
    lines( points, rep.int(0,length(points)), type="p", pch=19, lwd=2, col=colours[i] )
  }  
  
  # add an x-axis
  axis(1)
  
}


# plot the 2d clustering solution from k-means
plot2dClustering <- function( points, assignments ){
  
  # define colours
  colours <- rainbow(max(assignments))
  
  # set up the plot
  plot.new()
  plot.window( xlim=range( points[,1]), 
               ylim=range( points[,2]) )
  
  # draw the coloured points
  lines( points[,1], points[,2], type="p", pch=19,
         col=colours[assignments] )
  
  # add a box around the edge
  box()
  
}

# the custom plot for the RMC
# plus a custom plot
plotRMC <- function( trainingPoints, trainingLabels, assignments, cluster ){

  # define colours
  colours <- rainbow(max(assignments))
  marker <- c(21,24,25)
  
  # set up the plot
  plot.new()
  plot.window( xlim=range( trainingPoints[,1]), 
               ylim=range( trainingPoints[,2]) )
  
  # draw the coloured points
  lines( trainingPoints[,1], trainingPoints[,2], type="p", 
         pch=marker[trainingLabels+1], col="black",
         bg=colours[assignments] )
  
  # add a box around the edge
  box()
  
  # add the ellipses
  K <- length(cluster)
  for( k in 1:K ) {
    if( cluster[[k]]$n > 1) {
      addEllipse(mu=cluster[[k]]$mu, sigma=cluster[[k]]$sigma, unit=1.5,
                 col="black" )
    }
  }

}
