
####################### core functions used by multiple classifiers #######################

# distance function between point a and point b
# in m-dimensional space (Euclidean: r=2). Obviously,
# R already has functions to do this, but I find it
# handy to define my own, because you never know when
# you might want to redefine the meaning of "distance"
distance <- function(a,b,r=2){
  d <- (sum(abs(a-b)^r))^(1/r)
  return(d)
} 

# calculate the probability of a vector of x-values 
# if each is sampled from a Gaussian distribution 
# with mean mu and standard deviation sigma
gaussian <- function(x,mu,sigma){
  p <- dnorm(x, mean=mu, sd=sigma)
  return(p)
  
  # here's what would be if you coded it yourself:
  #
  #   p<- (sqrt(2*pi)*sigma)^-1 * exp( -(x-mu)^2 / (2*sigma^2) ) 
  
}

# calculate the probability of a matrix of x-values
# if each row is an observation sampled from a 
# multivariate Gaussian with mean vector mu and
# covariance matrix sigma
multivariateGaussian <- function(x,mu,sigma) {
  require( mvtnorm )
  p<-dmvnorm( x, mean=mu, sigma=sigma )
  return(p)
  
  # here's what it would be if you coded it yourself. Note that I haven't 
  # written this code exactly the way you'd need to. This version assumes 
  # that x is just a single vector. But, for those of you not using R, this
  # shoud give you a sense of what you need in order to do it yourself
  #
  #   k <- dim( sigma )[1]       ## number of dimensions
  #   invSig <- solve( sigma )   ## inverse of the covariance matrix
  #   detSig <- det( sigma )     ## determinant of the covariance matrix
  #   dx <- x-mu                 ## difference between observation x and mean mu
  #   p <- (2*pi)^(-k/2) * detSig^(-1/2)  * exp( -.5 * dx %*% invSig %*% dx  )  ## probability
  
}


####################### simple (univariate) Gaussian classifier #######################

simpleGaussianClassifier <- function( trainingPoints, trainingLabels, 
                                      testPoints=seq(0,1,.01), plot=TRUE ){
  
  # the code assumes that the labels are numeric: 1,2,3,...
  
  # handy things
  nClass <- max( trainingLabels ) # number of categories
  nTest <- length( testPoints ) # number of test points
  
  # set up important variables
  mu <- vector( length=nClass )
  sigma <- vector( length=nClass )
  prior <- vector( length=nClass )
  likelihood <- matrix( nrow=nTest, ncol=nClass)
  posterior <- matrix( nrow=nTest, ncol=nClass)
  
  # compute parameters for likelihood and prior
  for( i in 1:nClass ){
    exemplars <- trainingPoints[ trainingLabels == i ]
    prior[i] <- length( exemplars ) 
    mu[i] <- mean( exemplars )
    sigma[i] <- sd( exemplars )
  }
  prior <- prior / sum( prior )
  
  # compute the likelihoods and the (unnormalised) posteriors
  for( i in 1:nClass ){
    likelihood[,i] <- gaussian( testPoints, mu[i], sigma[i] )
    posterior[,i] <- likelihood[,i] * prior[i]
  }
  
  # draw the prior x likelihoods  
  if( plot ){
    plot1dClassifications( trainingPoints, trainingLabels, testPoints, posterior )
  }
  
  # normalise posteriors for each test point
  for( i in 1:nTest ){
    posterior[i,] <- posterior[i,] / sum( posterior[i,])
  }
  
  # draw the actual posterior probabilities  
  if( plot ){
    plot1dClassifications( trainingPoints, trainingLabels, testPoints, posterior )
  }
  
  # I'm childish, I know: I still find this funny.
  return( invisible( posterior ))
  
}


####################### multivariate Gaussian classifier #######################

multivariateGaussianClassifier <- function( trainingPoints, trainingLabels, 
                                            testPoints=testGrid(), plot=TRUE ){
  
  # the code assumes that the labels are numeric: 1,2,3,...
  
  # function to generate a category representation: assumed to
  # be a multivariate Gaussian defined over m dimensions
  estimateCategory <- function( points ){ 
    category <- list( # store relevant category information as a list
      mu = colMeans( points ), # the mean is a length-m vector
      sigma = cov( points ), # covariance matrix is an m by m matrix
      n = dim( points )[1] # number of observations
    )
    return( category )
  } 
  
  # function to return the likelihood of a set of observations
  # given a particular category
  computeLikelihood <- function( points, category ){ 
    likelihood <- multivariateGaussian( points, category$mu, category$sigma )  
    return( likelihood )
  }
  
  # set up variables
  nClass <- max( trainingLabels ) # number of categories
  nTest <- dim( testPoints )[1] # number of test points
  nDim <- dim( testPoints )[2] # number of dimensions
  category <- list() # store a list of category representations
  prior <- vector( length=nClass ) # vector of prior probabilities
  likelihood <- matrix( nrow=nTest, ncol=nClass ) # matrix of likelihoods
  posterior <- matrix( nrow=nTest, ncol=nClass ) # matrix of posteriors
  
  # compute all category representations
  for( i in 1:nClass ){
    category[[i]] <- estimateCategory( trainingPoints[ trainingLabels==i, ] )
  }
  
  # compute the prior, the likelihood and the unnormalised posterior
  for( i in 1:nClass ){
    prior[i] <- category[[i]]$n # prior is proportional to number of observations
    likelihood[,i] <- computeLikelihood( testPoints, category[[i]] ) # likelihood
    posterior[,i] <- likelihood[,i] * prior[i] # posterior
  }
  
  # normalise posteriors for each test point
  for( i in 1:nTest ){
    posterior[i,] <- posterior[i,] / sum( posterior[i,])
  }
  
  # draw picture if requested
  if( plot & nDim==2 & nClass==2 ){
    plot2dClassifications( trainingPoints, trainingLabels, testPoints, posterior[,2]+1 )
  }
  
  return( invisible( posterior ))
  
}



####################### k-nearest neigbours classifier #######################

kNN <- function(  trainingPoints, trainingLabels, k, testPoints=testGrid(), plot=TRUE ){  
  
  nTest <- dim( testPoints )[1]
  nTrain <- dim( trainingPoints )[1]
  nDim <- dim( trainingPoints )[2]
  nClass <- max( trainingLabels )
  testLabels <- vector( length=nTest )
  
  # return the indices of the k nearest neighbours,
  # given a set of distances d
  neighbours <- function(d,k) {
    nn <- order(d)[1:k]
    return(nn)
  }
  
  # x is a vector with values 1,2,3,...
  mostFrequent <- function( x ) {
    freq <- tabulate( x )
    
    # this was the original code. It introduces a minor bug in which
    # ties are broken non randomly.. if the tabulation of nearest 
    # neighbours was something like 3 3 1 0, what you want it to do
    # is return category 1 50% of the time and category 2 50% of the
    # time. What this line does, however, is always return the first
    # of the categories with maximum frequency (i.e. category 1 in 
    # this case) The new code fixes this.
    #
    # mode <- which.max( freq )
    
    # find all categories that have highest frequency among the
    # values in x
    allModes <- which( freq==max(freq) )
    
    if( length(allModes)==1 ){ # if there's only one mode...
      mode <- allModes # ... select it
    } else { # but if there's more than one mode...
      mode <- sample( allModes, 1 ) # ... pick one at a random
    }
    
    return(mode)
  }
  
  # classify
  for( i in 1:nTest ){
    
    # vector of distances from the test point to the training points
    d <- vector( length=nTrain )
    for( j in 1:nTrain ) {
      d[j] <- distance( trainingPoints[j,], testPoints[i,] )
    }
    
    # this uses a bunch of the helper functions
    nn <- neighbours( d, k ) # indices of the k nearest neighbours
    labs <- trainingLabels[nn] # labels for those neighbours
    testLabels[i] <- mostFrequent( labs ) # winner takes all
    
  }
  
  # draw if asked
  if( plot & nDim==2 & nClass==2 ){
    plot2dClassifications( trainingPoints, trainingLabels, testPoints, testLabels )
  }
  
  return( invisible( testLabels ))
}



####################### kernel density classifier #######################

kernelClass <- function( trainingPoints, trainingLabels, width, type="gaussian", 
                         testPoints = testGrid(), plot=TRUE ) {
  
  # return the kernel values for a set of 
  # distances d, given some kernel width w
  kernel <- function(d,w,type="gaussian"){
    if( type=="gaussian") k <- gaussian(d,0,w)
    if( type=="exponential") k <- exp(-w*d)
    return(k)
  }
  
  # coerce vector to 1-column matrix
  if( is.vector(trainingPoints)) {
    trainingPoints <- matrix( trainingPoints, ncol=1 )
    testPoints <- matrix( testPoints, ncol=1 )
  }
  
  # handy quantities
  nTest <- dim( testPoints )[1]
  nTrain <- dim( trainingPoints )[1]
  nDim <- dim( trainingPoints )[2]
  nClass <- max( trainingLabels )
  
  # set up storage
  summedKernelValue <- matrix( nrow=nTest, ncol=nClass )
  classProb <- matrix( nrow=nTest, ncol=nClass )
  
  # classify
  for( i in 1:nTest ){
    
    # distances
    d <- k <- vector( length=nTrain )
    for( j in 1:nTrain ) {
      d[j] <- distance( trainingPoints[j,], testPoints[i,] )
      k[j] <- kernel( d[j], width, type )
    }
    
    # compute and store the summed kernel values for each category
    for( j in 1:nClass ) {
      summedKernelValue[i,j] <- sum( k[trainingLabels==j] )
    }
    
    # convert kernel strengths to classification probabilities
    classProb[i,] <- summedKernelValue[i,] / sum( summedKernelValue[i,] )
    
  }
  
  
  # draw if asked
  if( plot & nDim==2 & nClass==2 ){
    plot2dClassifications( trainingPoints, trainingLabels, testPoints, classProb[,2]+1 )
  }
  
  # draw if asked
  if( plot & nDim==1 ){
    trainingPoints <- as.vector(trainingPoints)
    testPoints <- as.vector(testPoints)
    plot1dClassifications( trainingPoints, trainingLabels, testPoints, summedKernelValue )
    plot1dClassifications( trainingPoints, trainingLabels, testPoints, classProb )    
  }
  
  return(invisible(classProb))
}


####################### k-means classifier #######################

kMeans <- function( trainingPoints, k, plot=TRUE ){ 
  
  #### define a couple of helper functions ####
  
  # compute the cluster means 
  updateMeans <- function( points, assignments ) {
    
    # initialise
    k <- max(assignments) # <- this line is unnecessary, because R uses lexical scope
    m <- dim(points)[2] # number of dimensions
    means <- matrix( nrow=k, ncol=m ) 
    
    # recompute mean for each cluster
    for( i in 1:k ) {
      p <- points[assignments==i,,drop=FALSE] # <- drop=FALSE ensures R doesn't try to "drop" a 1 row matrix to a vector
      means[i,] <- colMeans( p ) # mean for each column
    }
    
    return(means)
  }
  
  # assign each point to the closest means
  updateAssignments <- function( points, means ) {
    
    # initialise
    k <- dim(means)[1] 
    n <- dim(points)[1]    
    d <- vector(length=k)
    assignments <- vector( length=n )
    
    # for each training point
    for( i in 1:n ) {
      
      # distances between all training points and the cluster means
      for( j in 1:k ) {  
        d[j] <- distance( points[i,], means[j,] ) 
      }
      
      # assign point to the cluster with the closest mean
      assignments[i] <- which.min(d) 
    }
    
    return( assignments ) 
  }
  
  #### now do the clustering ####
  
  # coerce vector input 1-column matrix
  if( is.vector( trainingPoints ) ){
    trainingPoints <- matrix( trainingPoints, ncol=1 )
  } 
  
  # set up
  nTrain <- dim(trainingPoints)[1] # number of points
  nDim <- dim(trainingPoints)[2] # number of dimensions
  oldAssignments <- rep.int(-1,nTrain) # hack to make sure it iterates at least once
  newAssignments <- sample(k,size=nTrain,replace=TRUE) # initial assignments are random
  
  # iterate until every point belongs to cluster with the closest mean
  while( any( oldAssignments != newAssignments ) ) { 
    
    means <- updateMeans( trainingPoints, newAssignments ) # update the means
    oldAssignments <- newAssignments # don't lose the old assignments
    newAssignments <- updateAssignments( trainingPoints, means ) # recompute new assignments
    
  }
  
  # draw if asked
  if( plot & nDim==2 ){
    plot2dClustering( trainingPoints, newAssignments )
  }
  
  # if a mean has vanished, pad with rows of NA
  if( dim(means)[1] < k ) {
    means <- rbind( means, matrix( NaN, k-dim(means)[1], nDim ))
  }
  
  return( invisible( list(means=means, assignments=newAssignments )))
  
}


####################### k-means + k-NN classifier #######################

reducedNN <- function( trainingPoints, trainingLabels, nClusters=5, 
                       neighbours=1, testPoints=testGrid(), plot=TRUE  ){
  
  nClass <- max( trainingLabels )
  nDim <- dim( trainingPoints )[2]
  
  clusterMeans <- matrix( nrow=nClusters*nClass, ncol=nDim )
  clusterLabels <- vector( length=nClusters*nClass )
  for( c in 1:nClass ) {
    points <- trainingPoints[ trainingLabels==c, ] # points that belong to the cluster
    ind <- (c-1)*nClusters + (1:nClusters) # indices into the matrix of means
    clusterMeans[ ind, ] <- kMeans( points, nClusters, plot=FALSE )$means # store the means
    clusterLabels[ind] <- c # associate each mean with the appropriate label
  }
  
  testLabels <- kNN( clusterMeans, clusterLabels, neighbours, testPoints, plot )
  
  if( plot & nDim==2 ){ # some additions to the default plot that kNN draws
    colours <- c("red","blue")
    lines( clusterMeans[,1], clusterMeans[,2], col=colours[clusterLabels],
           type="p", pch=19, cex=2)
    lines( trainingPoints[,1], trainingPoints[,2], type="p", pch=1, col=colours[labels])
  }
  
  return( invisible( list( testLabels=testLabels, clusterMeans=clusterMeans, clusterLabels=clusterLabels )))
  
} 


####################### the RMC classifier #######################

RMC <- function( trainingPoints, trainingLabels, alpha=2, clusterShare=10^-6, 
                 testPoints=testGrid(), plot=TRUE, initialTemperature=1,
                 finalTemperature=.01, coolingRate=.8, anneal=TRUE ){
  
  # In order to stop a cluster from ending up with degenerate (and overly-
  # narrow) covariance estimates we're going to use smoothed estimates. In
  # order to do that, we need to keep track of the grand mean (baseMu) and
  # overall covariance (baseSigma) across all training points. 
  baseMu <- matrix( colMeans( trainingPoints ), nrow=1 )
  baseSigma <- cov( trainingPoints )
  
  # We're also going to do some smoothing on theta too
  nClass <- max( trainingLabels )
  baseTheta <- rep.int( clusterShare, nClass )
  
  # this function takes an logical-index vector as input, and returns the full 
  # representation of the cluster. It relies heavily on R's scoping rules.
  # R uses lexical scope to determine which variables are in the scope chain
  # at any point in time. The key thing for this function is that the 
  # variables input to RMC() are all part of the scope chain at the time of
  # function definition, so I'll call them inside makeCluster()
  makeCluster <- function( cases ){ 
    
    n <- sum( cases ) # number of objects assigned to the cluster
    
    # empty cluster
    if( n==0 ) {  # <- in any other language I'd be using a switch/case construction. 
      points <- matrix( NA,0,0 )
      mu <- baseMu 
      sigma <- baseSigma
      theta <- baseTheta / sum( baseTheta )
    }
    
    # singleton cluster
    if( n==1 ) {
      points <- trainingPoints[cases,,drop=FALSE] # <- don't drop to vector. stay as a matrix
      labels <- trainingLabels[cases]
      mu <- (baseMu + points)/2 # treat the "base mean" as equivalent to 1 additional cluster member
      sigma <- baseSigma # one point isn't enough to determine variance or covariance, so keep baseSigma
      theta <- baseTheta + tabulate(labels,nClass)
      theta <- theta / sum(theta)
    } 
    
    # general case
    if( n>1 ) {
      points <- trainingPoints[cases,]
      labels <- trainingLabels[cases]
      sigma <- (n*cov( points ) + baseSigma) / (n+1)
      mu <- colMeans( rbind( points, baseMu ) )
      theta <- baseTheta + tabulate(labels,nClass)
      theta <- theta / sum(theta)
    }
    
    # return the cluster representation 
    cluster <- list( mu=mu, sigma=sigma, theta=theta, n=n, index=which(cases) )
    return( cluster )
    
  }
  
  # function to compute likelihood x prior for an item This has three components: the CRP prior,
  # the Gaussian likelihood, and the probability of the label (if the label is known) according 
  # to the cluster in question.
  getBelief <- function( features, label=0, clus ) {
    belief <- ifelse( test=clus$n==0, yes=alpha, no=clus$n ) # CRP prior
    belief <- belief * multivariateGaussian( x=features, mu=clus$mu, sigma=clus$sigma ) # gaussian likelihood
    if( label !=0 ) belief <- belief * clus$theta[ label ] # label probability
    return( belief )
  }
  
  # Function to make an assignment based on a belief vector and temperature. What this is doing
  # is taking the posterior (belief) distribution, and raising all the probabilities to some
  # exponent (low temp = high exponent). We sample our assignments, not from the original 
  # posterior, but from this new distribution with probabilities proportional to the posterior
  # raised to 1/temperature. What this does is cause the model to more strongly favour higher
  # probability assignments. As temperature -> 0, the assignment rule tends towards "always take
  # the best".
  getAssignment <- function( belief, temperature ) {
    sample( length(belief), size=1, prob=belief^(1/temperature) )
  }
  
  # handy things
  nTrain <- dim( trainingPoints )[1]
  nTest <- dim( testPoints )[1]
  nDim <- dim( trainingPoints )[2]
  temperature <- initialTemperature
  
  # initialise the cluster representation
  K <- 0 # number of non-empty clusters
  cluster <- list() # we're going to store a list of clusters
  cluster[[1]] <- makeCluster(FALSE) # initialise with one empty cluster
  assignments <- rep.int( 0, nTrain ) # all assignments are missing
  
  # do one or more sweeps through the data
  done <- FALSE
  while( !done ) {
    
    # random order with which to sweep through the data set
    sweep <- sample(nTrain,nTrain)
    
    # do a sweep
    for( i in 1:nTrain ){
      
      # if the current item is already assigned to a cluster, we first
      # need to remove it from that cluster, and update all the representations
      # accordingly 
      if( assignments[sweep[i]] !=0 ) {
        
        k <- assignments[sweep[i]] # what cluster was it assigned to?
        assignments[sweep[i]] <- 0 # tag it for removal
        
        if( sum(assignments==k) > 0 ) { # if that cluster still has observations...
          cluster[[k]] <- makeCluster( assignments==k ) # ... update the cluster
          
        } else{ # if it's now empty...
          cluster <- cluster[-k] # ...remove it
          assignments[ assignments > k] <- assignments[ assignments > k]-1 # ...and update the index
          K <- K-1 # ... and the cluster count
        }
      }
      
      # next, grab the stimulus item
      features <- trainingPoints[sweep[i],]
      label <- trainingLabels[sweep[i]]
      
      # compute posterior distribution over cluster assignments, including 
      # the possibility that this item belongs to a new cluster (i.e., K+1)
      belief <- vector( length=K+1 )
      for( k in 1:(K+1) ){
        belief[k] <- getBelief( features, label, cluster[[k]] )
      }
      belief <- belief/sum(belief)
      
      # determine which cluster it should be assigned to
      k <- getAssignment( belief, temperature )
      
      # update everything 
      assignments[sweep[i]] <- k # update the indexing vector
      cluster[[k]] <- makeCluster( assignments==k ) # update the cluster representation
      if( k == K+1 ){ # if it's a new cluster...
        K <- K+1 # ... update cluster count
        cluster[[K+1]] <- makeCluster(FALSE) # ... and create a new "empty" cluster for next time 
      } 
    }
    
    
    # see if the termination conditions are met
    if( temperature < finalTemperature | anneal==FALSE ) { 
      done <- TRUE 
    } else {
      temperature <- temperature * coolingRate
      cat( "temperature:", round(temperature,2),  "\n" )
    }
    
  }
  
  # now that we're finihsed, remove the empty cluster at the end of the list
  cluster <- cluster[-(K+1)]
  
  # classify the test points 
  labelPosterior <- matrix( 0, nTest, nClass ) # posterior distribution over test labels
  clusterPosterior <- vector( length=K ) # vector to store posterior over cluster assignments
  for( i in 1:nTest ) { # for all test points
    
    # compute the posterior distribution over possible clusters that 
    # the test point should be assigned to. we don't know the label,
    # so the assignment is based only on the feature values
    for( k in 1:K) {
      clusterPosterior[k] <- getBelief( testPoints[i,], 0, cluster[[k]] )
    }
    clusterPosterior <- clusterPosterior / sum( clusterPosterior )
    
    # each cluster is associated with a distribution over labels. Use
    # this to compute the posterior distribution over labels for the 
    # test item
    for( k in 1:K ) {
      labelPosterior[i,] <- labelPosterior[i,] + clusterPosterior[k] * cluster[[k]]$theta
    }
  }
  
  # draw pictures if asked
  if( plot & nDim==2 & nClass==2 ){
    plot2dClassifications( trainingPoints, trainingLabels, 
                           testPoints, labelPosterior[,2]+1 ) # standard plot
    plotRMC( trainingPoints, trainingLabels, assignments, cluster ) # custom plot
  }
  
  return(invisible(list(cluster=cluster,posterior=labelPosterior)))
  
}


