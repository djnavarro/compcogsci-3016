
#####  load and source everything #####
dir <- "~/Work/Teaching/ccs2014/Code/Classification/"
load( paste0( dir, "dataset.Rdata" ))
source( paste0( dir, "classificationHelpers.R" ))
source( paste0( dir, "classifiers.R" ))
toyFeature <- c( .1, .2, .45, .55, .9, .7,.75 )
toyLabel <- c(1, 1, 2, 2, 2, 3,3) 


#####  Gaussian classifier ##### 
simpleGaussianClassifier( toyFeature, toyLabel )
multivariateGaussianClassifier( features, labels )

#####  k nearest neighbours classifier ##### 
kNN( features, labels, k=5 )

#####  kernel classifier ##### 
kernelClass( toyFeature, toyLabel, width=.05, testPoints=seq(0,1,.01) )
kernelClass( features, labels, width=.1 )

#####  k-means ##### 
kMeans( features, k=5 )

#####  reduced kNN via k-means ##### 
reducedNN( features, labels, nClusters=5, neighbours=1 )

#####  RMC ##### 
RMC( features, labels )
RMC( features, labels, clusterShare=1000 )

labels2 <- labels
labels2[ runif(length(labels2))<.8 ] <- 0 # delete 80% of the labels
RMC( features, labels2, clusterShare=1 )
