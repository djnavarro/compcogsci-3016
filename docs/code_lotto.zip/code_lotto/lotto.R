# The lotto problem. The code here is (deliberately) very
# inefficient. Vectorised code is much faster in R, but
# very hard to read if you're not used to using R. Along
# the same lines, I've tried to stick to data structures
# that are common to most languages. This isn't a class
# on code optimisation! (And you certainly wouldn't want
# psychologists to be teaching that class...)

lotto <- function( x, plot=TRUE ) {

  # number of hypotheses is modest, but too large to solve
  # by hand (though in this case it is possible to use calculus
  # to solve the problem analytically)
  nH <- 5050 
  
  # create the hypothesis space: each hypothesis is 
  # defined by a lower bound and an upper bound on the
  # possible winning number in the lottery
  hypotheses <- matrix( nrow=nH, ncol=2 )
  ind <- 0
  for( lowerBound in 1:100 ) {
    for( upperBound in lowerBound:100 ){
      ind <- ind+1
      hypotheses[ ind, ] <- c( lowerBound, upperBound)
    }
  }
  
  # specify a prior distribution: all hypotheses are 
  # equally likely
  prior <- rep.int( 1/nH, nH )
  
  # matrix containing likelihoods for all possible 
  # values between 1 and 100, as specified by all
  # 5050 hypotheses
  likelihood <- matrix( data=0, nrow=nH, ncol=100 ) # initialise at zero
  for( h in 1:nH ){
    values <- hypotheses[h,1] : hypotheses[h,2] # possible values according to this hypothesis
    size <- length( values ) # how many such values are there
    likelihood[ h, values ] <- 1/size # all possible values are equally likely
  }  

  # likelihood of the observed data
  posterior <- prior # initialise the posterior at the prior
  for( obs in x ) { # loop over the observations
    posterior <- posterior * likelihood[,obs] # update the posterior 
  }
  
  # "normalise" the posterior so that it sums to 1
  posterior <- posterior / sum( posterior )
  
  # now solve the bookie's problem: what is the probability that
  # a particular value will turn out to be within the true region
  answer <- vector( length=100 )
  for( v in 1:100 ) {
    consistentHypotheses <- (hypotheses[,1] <= v) & (hypotheses[,2] >= v)
    answer[v] <- sum( posterior[consistentHypotheses] ) 
  }

  # plot if need be
  if( plot==TRUE ) {
    
    # convert posterior distribution to a matrix
    posteriorMatrix <- matrix(data=0, nrow=100, ncol=100)
    for( h in 1:nH ) {
      l <- hypotheses[h,1]y
      u <- hypotheses[h,2]
      posteriorMatrix[l,u] <- posterior[h]
    }
    
    # draw 2d heat map
    image( 1:100, 1:100, posteriorMatrix, range(posterior),
           col=grey( seq(1,0,-.01)), xlab="Lower Bound",
           ylab="Upper Bound", main="Posterior Probability" )
    abline(0,1)
    
    # show a 3d perspective plot
    persp( 1:100, 1:100, posteriorMatrix, theta=20, phi=40,
           xlab="Lower Bound", ylab="Upper Bound", 
           zlab="Posterior Probability", col="lightblue" )
    
    # draw the generalisation plot
    plot( answer, type="o",lwd=2, xlab="Number Bet Upon",  
          ylab="Probability of Being in the Valid Region",
          main=paste("Outcomes so far: ", paste(x, collapse=", ")),
          ylim=c(0,1), pch=19, cex=.4 )
    lines( x, rep.int(0,length(x)), type="p", pch=19 )

    
    
  }
  
  return(answer)
}
