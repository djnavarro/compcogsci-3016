function [G, H, postH]=lotto(X)

% [G, H, postH] = lotto(X)
%
% Function to solve the lotto problem. This
% code is not efficient - Matlab is optimised for matrix
% operations, so it would be better to rewrite the loops
% as vector or matrix operations. But efficient code is
% less important here than readable code!
%
% Input:
%
% X is a vector listing the known winning numbers so far. 
%
% Output:
%
% G is a vector listing the probabilities that every possible
% number (between 10 and 99) falls within the allowed range
%
% H is the hypothesis space (a 2 by 4095 matrix) of possible
% ranges 
%
% postH is the posterior distribution (a vector)


% IMPORTANT NOTE: this code is from 2012, when we used to 
% teach primarily in Matlab / Octave. Notice that the 
% specification of the problem is subtly different to the
% one from the 2014 lectures


% set up the hypothesis space
H = []; 
for l = 10:99 % lower value
	for u = l:99 % upper value
		 H = [H; l u]; % add hypothesis 
	end
end

% set up the prior over the hypothesis space
nh = size(H,1); % count the number of hypotheses
priorH = ones(nh,1) / nh; % all hypothesis equally likely

% set up the likelihood functions
L = zeros(nh,100); % initialise P(x|h) at zero for all x & h
for h = 1:nh % loop over hypotheses

	% get the relevant information
	l = H(h,1); % the lower bound as per hypothesis h
	u = H(h,2); % the upper bound as per hypothesis h
	s = u - l + 1; % the "size" of the hypothesis h, |h|
	
	% specify the likelihood
	L(h,l:u) = 1/s; % P(x|h) = 1/|h| for all x in h
end

% [an aside: notice that our matrix L is mostly zeros. That
% is, it is sparse. Matlab is much faster when dealing with 
% sparse matrices if you actually tell it to expect a sparse
% matrix. There's a function called "sparse" that does this.
% I won't bother here.] 


% likelihood of the observed data
nx = length(X); % number of observations
pX = ones(nh,1); % initialise 
for i = 1:nx % loop over all X
	xi = X(i); % the i-th datum
	pX = pX .* L(:,xi); % update likelihood
end

% compute posterior inefficiently...
postH = (pX .* priorH) / sum(pX .* priorH);

% generalisation probability
y = 10:99; % values people might bet on
ny = length(y); % number of such values
G = zeros(1,ny); % initialise
for i = 1:ny
	ind = y(i) >= H(:,1) & y(i) <= H(:,2); 
	G(i) = sum(postH(ind));
end





