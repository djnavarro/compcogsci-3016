source('kmeanshelperfns.R')
source('mogsupportfns.R')

##### mixtureofgaussians code. This code is 
# deliberately inefficient, in favour of clarity.
# % This algorithm is basically softkmeansclusterversion2 (pg 304 of MacKay),
# i.e., it is like softkmeanscluster except that the responsibilities
# are calculated assuming that the clusters are Gaussians. This actually
# has a similar functional form to the calculation in softkmeanscluster.R,
# but it is not identical. Also, unlike softkmeanscluster.R, it is not
# assumed that all clusters have the same variance. Thus, in addition to
# the step where means are adjusted, there is also a step where the
# variances are adjusted. There is no BETA parameter this time. Also, the
# clusters themselves have weight parameters W, allowing for clusters of
# unequal weights.
# this code takes some data D with x and y coordinates 
# and the number of clusters to find, k

mixtureofgaussians <- function( d, k ) {
  
  nn <- length(d$x)   # get the total number of datapoints
  # first step: set each mean randomly to one of the datapoints
  m <- sample(1:nn,k)
  means <- list(x=d$x[m],y=d$y[m]) 
  mprev <- means
  
  # set initial responsibilities to all one
  # column = datapoint n
  # row = the cluster
  # r(k,n)=1 if it's in that cluster
  rprev <- matrix(0,k,nn)
  rcurr <- matrix(1,k,nn)

  # set initial weights to be all even
  w <- rep(1/k,k)
  
  # set initial standard deviations to be equal
  # (assumes there are only two dimensions)
  # this variable is sigma^2, not sigma
  sigmasq <- matrix(0.05,k,2) 
  
  plotdataset( d, d$colours, k, means, new=TRUE )
  Sys.sleep(0.4)
  
  # loop until the assignments (responsibilities) have not changed
  # to prevent really long loops we'll allow a little bit of slop in the
  # assignments
  slop <- 0.05
  while (any(rcurr>rprev+slop) | any(rcurr<rprev-slop)) {
    rprev <- rcurr
    rcurr <- matrix(0,k,nn)
    
    # do the assignment step (e-step)
    ###  INSERT E-STEP CODE HERE
    
    # renormalise rcurr
    denom <- colSums(rcurr)
    for (nk in 1:k)
      rcurr[nk,] <- rcurr[nk,]/denom
    R <- rowSums(rcurr)
    
    # next, recalculate the means, variances, and weights. 
    # each datapoint contributes proportionally to how much it is in there
    ###  INSERT M-STEP CODE HERE
    
    plotdataset( d, rcurr, k, means, new=FALSE )
    Sys.sleep(0.4)
  }
  return(rcurr)
}