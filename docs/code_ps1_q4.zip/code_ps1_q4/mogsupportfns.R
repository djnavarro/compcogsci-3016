install.packages("mcclust")
library('mcclust')

## a necessary helper function: makes it so all the cells in a vector VEC are in
# numerical order, i.e., c(3,1,1,2,3) --> c(1,2,2,3,1). this is necessary to 
# properly compare two clusters
substituteorder <- function(vec) {
  newvec <- rep(NA,length(vec))
  for (k in 1:max(vec)) {
    curr <- match(TRUE,vec>0)
    newvec[vec==vec[curr]] <- k
    vec[vec==vec[curr]] <- 0
  }  
  return(newvec)
}

##### returns the adjusted rand index between the two cluster groupings
# (CLUSTERA and CLUSTERB). these are basically the responsibility matrices RCURR
# that you calculate in mixtureofgaussians.R or kmeanscluster.R. 
# adjusted rand index gives a value of 1 if the clusters are exactly the same,
# 0 if they are as similar as you would expect by chance, and a negative number
# if they are *less* similar as you would expect by chance. when rcurr
# has soft cluster assignments, the rand index is calculated by assuming each
# point is in the cluster with the most probability for that point.
getrandindex <- function(clusterA,clusterB) {
  
  # first remove soft assignments
  cA <- apply(clusterA,2,which.max)
  cB <- apply(clusterB,2,which.max)
  
  # now make both clusters comparable
  cA <- substituteorder(cA)
  cB <- substituteorder(cB)
  
  # get adjusted rand index
  rand <- arandi(cA,cB)
  return(rand)
}
