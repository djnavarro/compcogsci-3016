########### getbigramtallies ##########
# returns a list with unigram and bigram counts, raw, and conditional
# probabilities. In the bigram arrays, columns are word1 and rows are word2.
# e.g., if you run 
#     tallies <- getbigramtallies("weather.txt") you can then ask
#   tallies$bi.counts["to","up"] and it will give you the number of times the 
# bigram "up to" has occurred in the corpus. tallies$uni.counts["up"] gives 
# the number of times the unigram "up" has occurred. you can run similar
# queries to get the conditional probabilities (bi.conditional) or raw
# frequencies (bi.raw or uni.raw).

getbigramtallies <- function( filename ) {
  
  # read the corpus in, putting all in lowercase
  corpus <- tolower(scan(file=filename, what="character"))
  
  # remove periods, commas, and apostrophes
  corpus <- gsub("[.,':;()’!?]","",corpus)
  corpuslength <- length(corpus)
  
  # uni.list is just the set of words in the corpus (i.e., the list of unigrams)
  # bi.list is the set of possible bigrams
  uni.list <- sort(unique(corpus))  
  nwords <- length(uni.list)
  
  # unigram count list is just a frequency table
  # for unigrams, raw and conditional are the same so just do raw
  uni.counts <- table(corpus)
  uni.raw <- uni.counts/sum(uni.counts)
  
  # initialise bigram counts
  bi.counts <- matrix(0,nwords,nwords)
  bi.list <- rep("",nwords*nwords/2)
  rownames(bi.counts) <- uni.list
  colnames(bi.counts) <- uni.list

  # loop through corpus and tally bigrams to get bigram counts
  b <- 1
  for (c in 2:corpuslength) {
    bi.counts[corpus[c],corpus[c-1]] <- bi.counts[corpus[c],corpus[c-1]] + 1
    bi.list[b] <- paste(corpus[c-1],corpus[c],sep=" ")
    b <- b+1
  }
  bi.list <- unique(bi.list)
  # normalise and return
  bi.conditional <- apply(bi.counts,2,function(x){x/sum(x)})
  bi.raw <- bi.counts/sum(bi.counts)
  tallies <- list(uni.list=uni.list, uni.counts=uni.counts, uni.raw=uni.raw,
                  bi.list=bi.list, bi.counts=bi.counts, bi.raw=bi.raw, bi.conditional=bi.conditional)
  return(tallies)
}

############### getlaplacebigramtallies #########
# returns a list with unigram and bigram counts, raw, and conditional
# probabilities, assuming laplacian smoothing where LAMBDA is the number of
# hypothetical counts (LAMBDA=1 in the example given in lecture, because we 
# pretend that each n-gram has occurred once and then recalculate all
# probabilities accordingly). This file takes two file names and constructs
# lists of possible bigrams and words using the joint vocabulary from both.
# however it only returns the smoothed n-gram probabilities for the first
# filename.

getlaplacebigramtallies <- function( filenameA, filenameB, lambda=1 ) {
 # INSERT CODE HERE 
}
  

################## plotngrams #########
# makes some not-too-fancy graphs of the unigram and bigram tallies

plotngrams <- function(tallies) {
  unigramfreqs <- sort(tallies$uni.counts,decreasing=TRUE)
  plot(unigramfreqs,ylab="frequency",xlab="",pch=16,cex=1.2,
       col="steelblue3",xaxt="n",main="Word frequencies")
  bigramfreqs <- sort(tallies$bi.counts,decreasing=TRUE)
  plot(bigramfreqs,ylab="bigram frequency",xlab="",pch=16,cex=1.2,
       col="steelblue3",xaxt="n",main="Bigram frequencies")
  #image(tallies$bi.raw,col=gray.colors(100,start=1,end=0),
  #      main="Bigram table",xaxt="n",yaxt="n")#,xlab="Word 1",ylab="Word 2")
}

################ calculateoverlap ##############
# function returns the percentage of words that were in TALLIESA 
# that are also in TALLIESB, and vice versa
calculateoverlap <- function( talliesA, talliesB ) {
  # gets the n-grams that are in both corpora
  uni.both <- intersect(talliesA$uni.list,talliesB$uni.list)
  bi.both <- intersect(talliesA$bi.list,talliesB$bi.list)
  # returns the percent in B that were not in A
  print(paste("unigram: ",1-length(uni.both)/length(talliesB$uni.list),"% not shared"))
  print(paste("bigram: ",1-length(bi.both)/length(talliesB$bi.list),"% not shared"))
}

############### getlaplacebigramtallies #########
# returns a list with unigram and bigram counts, raw, and conditional
# probabilities, assuming lidstone smoothing where LAMBDA is the number of
# hypothetical counts (LAMBDA=1 in the example given in lecture, because we 
# pretend that each n-gram has occurred once and then recalculate all
# probabilities accordingly). This file takes two file names and constructs
# lists of possible bigrams and words using the joint vocabulary from both.
# however it only returns the smoothed n-gram probabilities for the first
# filename.
getlaplacebigramtallies <- function( filenameA, filenameB, lambda=1 ) {
  # INSERT YOUR CODE FOR PART E HERE
}

  