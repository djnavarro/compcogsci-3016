
###### multivariateGaussian #####
# calculate the probability of a matrix of x-values
# if each row is an observation sampled from a 
# multivariate Gaussian with mean vector mu and
# covariance matrix sigma
multivariateGaussian <- function(x,mu,sigma) {
  require( mvtnorm )
  p<-dmvnorm( x, mean=mu, sigma=sigma )
  return(p)  
}

###### substituteorder ######
# makes it so all the cells in a vector VEC are in
# numerical order, i.e., c(3,1,1,2,3) --> c(1,2,2,3,1). this is necessary to 
# properly compare two clusters
substituteorder <- function(vec) {
  newvec <- rep(0,length(vec))
  for (k in 1:max(vec)) {
    curr <- match(TRUE,vec>0)
    newvec[vec==vec[curr]] <- k
    vec[vec==vec[curr]] <- 0
  }  
  return(newvec)
}

##### getrandindex #######
# returns the adjusted rand index between the two cluster groupings
# (CLUSTERA and CLUSTERB). these are basically the responsibility matrices RCURR
# that you calculate in mixtureofgaussians.R or kmeanscluster.R. 
# adjusted rand index gives a value of 1 if the clusters are exactly the same,
# 0 if they are as similar as you would expect by chance, and a negative number
# if they are *less* similar as you would expect by chance. when rcurr
# has soft cluster assignments, the rand index is calculated by assuming each
# point is in the cluster with the most probability for that point.
getrandindex <- function(cA,cB) {
  
  library('mcclust')

  # make both clusters comparable
  cA <- substituteorder(cA)
  cB <- substituteorder(cB)
  
  # get adjusted rand index
  rand <- arandi(cA,cB)
  return(rand)
}


####################### the RMC classifier #######################

RMC <- function( trainingPoints, trainingLabels, alpha=2, clusterShare=10^-6, 
                 testPoints=testGrid(), plot=TRUE, initialTemperature=1,
                 finalTemperature=.01, coolingRate=.8, anneal=TRUE ){
  
  # In order to stop a cluster from ending up with degenerate (and overly-
  # narrow) covariance estimates we're going to use smoothed estimates. In
  # order to do that, we need to keep track of the grand mean (baseMu) and
  # overall covariance (baseSigma) across all training points. 
  baseMu <- matrix( colMeans( trainingPoints ), nrow=1 )
  baseSigma <- cov( trainingPoints )
  
  # We're also going to do some smoothing on theta too
  nClass <- max( trainingLabels )
  baseTheta <- rep.int( clusterShare, nClass )
  
  # this function takes an logical-index vector as input, and returns the full 
  # representation of the cluster. It relies heavily on R's scoping rules.
  # R uses lexical scope to determine which variables are in the scope chain
  # at any point in time. The key thing for this function is that the 
  # variables input to RMC() are all part of the scope chain at the time of
  # function definition, so I'll call them inside makeCluster()
  makeCluster <- function( cases ){ 
    
    n <- sum( cases ) # number of objects assigned to the cluster
    
    # empty cluster
    if( n==0 ) {  # <- in any other language I'd be using a switch/case construction. 
      points <- matrix( NA,0,0 )
      mu <- baseMu 
      sigma <- baseSigma
      theta <- baseTheta / sum( baseTheta )
    }
    
    # singleton cluster
    if( n==1 ) {
      points <- trainingPoints[cases,,drop=FALSE] # <- don't drop to vector. stay as a matrix
      labels <- trainingLabels[cases]
      mu <- (baseMu + points)/2 # treat the "base mean" as equivalent to 1 additional cluster member
      sigma <- baseSigma # one point isn't enough to determine variance or covariance, so keep baseSigma
      theta <- baseTheta + tabulate(labels,nClass)
      theta <- theta / sum(theta)
    } 
    
    # general case
    if( n>1 ) {
      points <- trainingPoints[cases,]
      labels <- trainingLabels[cases]
      sigma <- (n*cov( points ) + baseSigma) / (n+1)
      mu <- colMeans( rbind( points, baseMu ) )
      theta <- baseTheta + tabulate(labels,nClass)
      theta <- theta / sum(theta)
    }
    
    # return the cluster representation 
    cluster <- list( mu=mu, sigma=sigma, theta=theta, n=n, index=which(cases) )
    return( cluster )
    
  }
  
  # function to compute likelihood x prior for an item This has three components: the CRP prior,
  # the Gaussian likelihood, and the probability of the label (if the label is known) according 
  # to the cluster in question.
  getBelief <- function( features, label=0, clus ) {
    belief <- ifelse( test=clus$n==0, yes=alpha, no=clus$n ) # CRP prior
    belief <- belief * multivariateGaussian( x=features, mu=clus$mu, sigma=clus$sigma ) # gaussian likelihood
    if( label !=0 ) belief <- belief * clus$theta[ label ] # label probability
    return( belief )
  }
  
  # Function to make an assignment based on a belief vector and temperature. What this is doing
  # is taking the posterior (belief) distribution, and raising all the probabilities to some
  # exponent (low temp = high exponent). We sample our assignments, not from the original 
  # posterior, but from this new distribution with probabilities proportional to the posterior
  # raised to 1/temperature. What this does is cause the model to more strongly favour higher
  # probability assignments. As temperature -> 0, the assignment rule tends towards "always take
  # the best".
  getAssignment <- function( belief, temperature ) {
    sample( length(belief), size=1, prob=belief^(1/temperature) )
  }
  
  # handy things
  nTrain <- dim( trainingPoints )[1]
  nTest <- dim( testPoints )[1]
  nDim <- dim( trainingPoints )[2]
  temperature <- initialTemperature
  
  # initialise the cluster representation
  K <- 0 # number of non-empty clusters
  cluster <- list() # we're going to store a list of clusters
  cluster[[1]] <- makeCluster(FALSE) # initialise with one empty cluster
  assignments <- rep.int( 0, nTrain ) # all assignments are missing
  
  # do one or more sweeps through the data
  done <- FALSE
  while( !done ) {
    
    # random order with which to sweep through the data set
    sweep <- sample(nTrain,nTrain)
    
    # do a sweep
    for( i in 1:nTrain ){
      
      # if the current item is already assigned to a cluster, we first
      # need to remove it from that cluster, and update all the representations
      # accordingly 
      if( assignments[sweep[i]] !=0 ) {
        
        k <- assignments[sweep[i]] # what cluster was it assigned to?
        assignments[sweep[i]] <- 0 # tag it for removal
        
        if( sum(assignments==k) > 0 ) { # if that cluster still has observations...
          cluster[[k]] <- makeCluster( assignments==k ) # ... update the cluster
          
        } else{ # if it's now empty...
          cluster <- cluster[-k] # ...remove it
          assignments[ assignments > k] <- assignments[ assignments > k]-1 # ...and update the index
          K <- K-1 # ... and the cluster count
        }
      }
      
      # next, grab the stimulus item
      features <- trainingPoints[sweep[i],]
      label <- trainingLabels[sweep[i]]
      
      # compute posterior distribution over cluster assignments, including 
      # the possibility that this item belongs to a new cluster (i.e., K+1)
      belief <- vector( length=K+1 )
      for( k in 1:(K+1) ){
        belief[k] <- getBelief( features, label, cluster[[k]] )
      }
      belief <- belief/sum(belief)
      
      # determine which cluster it should be assigned to
      k <- getAssignment( belief, temperature )
      
      # update everything 
      assignments[sweep[i]] <- k # update the indexing vector
      cluster[[k]] <- makeCluster( assignments==k ) # update the cluster representation
      if( k == K+1 ){ # if it's a new cluster...
        K <- K+1 # ... update cluster count
        cluster[[K+1]] <- makeCluster(FALSE) # ... and create a new "empty" cluster for next time 
      } 
    }
    
    
    # see if the termination conditions are met
    if( temperature < finalTemperature | anneal==FALSE ) { 
      done <- TRUE 
    } else {
      temperature <- temperature * coolingRate
      cat( "temperature:", round(temperature,2),  "\n" )
    }
    
  }
  
  # now that we're finihsed, remove the empty cluster at the end of the list
  cluster <- cluster[-(K+1)]
  
  # classify the test points 
  labelPosterior <- matrix( 0, nTest, nClass ) # posterior distribution over test labels
  clusterPosterior <- vector( length=K ) # vector to store posterior over cluster assignments
  for( i in 1:nTest ) { # for all test points
    
    # compute the posterior distribution over possible clusters that 
    # the test point should be assigned to. we don't know the label,
    # so the assignment is based only on the feature values
    for( k in 1:K) {
      clusterPosterior[k] <- getBelief( testPoints[i,], 0, cluster[[k]] )
    }
    clusterPosterior <- clusterPosterior / sum( clusterPosterior )
    
    # each cluster is associated with a distribution over labels. Use
    # this to compute the posterior distribution over labels for the 
    # test item
    for( k in 1:K ) {
      labelPosterior[i,] <- labelPosterior[i,] + clusterPosterior[k] * cluster[[k]]$theta
    }
  }
  
  # draw pictures if asked
  if( plot & nDim==2 ){  # removed & nClass==2
    #plot2dClassifications( trainingPoints, trainingLabels, 
    #                       testPoints, labelPosterior[,2]+1 ) # standard plot
    plotRMC( trainingPoints, trainingLabels, assignments, cluster ) # custom plot
  }
  
  return(invisible(list(cluster=cluster,posterior=labelPosterior)))
  
}

####################### runRMC #######################
# runs the RMC classifier for problem set 2

runRMC <- function() {

  dir <- ""
  nitems <- 36
  source( paste0( dir, "classificationHelpers.R" ))
  
  # create initial 6x6 dataset of food items with no cluster structure
  features <- testGrid(x=seq(0.15,0.9,0.15),y=seq(0.15,0.9,0.15))
  
  # there are 36 labels, one for each item, but only 50% are presented to the learner
  labels <- round(runif(nitems,1,nitems))
  labels[ runif(length(labels))<.5 ] <- 0 # delete 50% of the labels
  labels <- substituteorder(labels)
  
  # run the RMC on it 
  # colours of items in the plot reflect labels assigned by the RMC
  #      (e.g., all red items share the same label)
  # In the final plots, small filled circles indicate the data points that 
  #    initially went unlabelled; each other shapes corresponds to a distinct 
  #    initial labels.
  # clusters inferred by the RMC are shown for clusters containing more
  #     than one item
  alphaval <- 0.1
  res <- RMC( features, labels, alpha=alphaval)
  
  # transform results into new labels vector
  nclust <- length(res$cluster)
  newlabels <- rep(0,nitems)
  for (c in 1:nclust)
    newlabels[res$cluster[[c]]$index] <- c

}



