
# function that generates a time of death for each patient by sampling it from
# a poisson distribution with some parameter RATE. This is expected to be a 
# vector of length 3
deathTimes <- function( rate ){
  d <- rpois( n=length(rate), lambda=rate )
  return(d)
}

# function that generates a time-required-to-treat for all three patients by 
# sampling it from a uniform distribution that lies between MIN and MAX. The
# input arguments MIN and MAX must both be vectors of length 3
treatmentTimes <- function( min, max ){
  t <- c(0,0,0)
  for( i in 1:3 ) t[i] <- sample(min[i]:max[i],1)
  return(t)
}


# given a set of three DEATH times, a set of three TREATMENT times, and an ORDER in which
# to treat the patients (e.g., c(2,1,3) ), return a logical vector of length three that 
# indicates who lives and who dies
findSurvivors <- function( death, treatment, order ){
  alive <- c(TRUE,TRUE,TRUE)
  time <- 0
  for( o in order ){ # treat patients in order
    alive[o] <- death[o] > (time + treatment[o]) # does the current patient live?
    if( alive[o] ) {
      time <- time + treatment[o] # if they lived, the whole treatment time is spent on treatment
    } else {
      time <- max( time, death[o] ) # if the patient died earlier, no additional time elapses. but if the patient dies mid-treatment, then some time elapses
    }
  }
  return(alive)
}

# given a vector describing the death RATE for each patient, the MIN treatment time and the MAX treatment time
# for the patient, generate a single simulation: i.e., generate DEATH and TREATMENT times, and then see who lives and
# who dies for all six possible treatment orders...
simulateProcess <- function( rate, min, max ) {
  
  # all possible treatment orders
  ords <- rbind( 
      c(1,2,3), c(1,3,2), c(2,1,3), c(2,3,1), c(3,1,2), c(3,2,1)
  )
  
  # treatment times and death times
  t <- treatmentTimes( min, max )
  d <- deathTimes( rate ) 
  
  # simulate the process for all possible treatment orders
  survivors <- matrix(NA,6,3) # 6x3 logical matrix indicating who lived and who died under each treatment order
  for( i in 1:6 ){
    survivors[i,] <- findSurvivors( d, t, ords[i,] )
  }
  
  return(survivors)
  
}


# main function: run lots of simulations to see who lives and dies under each treatment ordering...
triage <- function( n=1000, rate=c(10,20,15), min=c(6,2,11), max=c(15,50,30), expand=FALSE ){
  
  #### initialise ####
  
  # if expand==FALSE, do a simpler version where you just keep track of the number of times that
  # patient A lives, patient B lives and patient C lives under each treatment order. This is the
  # version reported in lecture slides
  if( expand==FALSE) {
    survivors <- matrix(0,6,3)
    rownames(survivors) <- c("abc","acb","bac","bca","cab","cba")
    colnames(survivors) <- c("a","b","c")
    
  # if expand=TRUE, do a more complex version where you track the frequency of all 8 possible outcomes
  # under each treatment ordering. (this is especially useful if you want to see what the probability of
  # "everybody lives" is)
  } else{ 
    survivors <- matrix(0,6,8)
    rownames(survivors) <- c("abc","acb","bac","bca","cab","cba")
    colnames(survivors) <- c("abc","ab","ac","bc","a","b","c","-")
  }
  
  ### run simulations ###
  
  for( i in 1:n ){ # loop over n simulations
    s <- simulateProcess( rate, min, max ) # run the simulation
    
    # store the simplified output if that's what's requested
    if( expand==FALSE) {
      survivors <- survivors + s 
      
    # otherwise store the more complex output 
    } else {
      for( i in 1:6 ) {
        ind <- paste( c("a","b","c")[which( s[i,] )], collapse="" )
        if( ind=="") ind <- "-"
        survivors[i,ind] <- survivors[i,ind]+1
      }
    }
    
  }
  
  # convert to percentages
  survivors <- round( 100*survivors/n )
  
  # return the results
  return(survivors)
  
}