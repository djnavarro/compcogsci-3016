
# the value function used in the example from the slides
valueFunction <- function( z, r ) { 
  if( z >= r ) { 
    v <- log( 1+8*(z-r))  # if it's a gain
  } else {
    v <- - log2( 1+8*(r-z))  # if it's a loss 
  }
  return(v)
}


# probability of each outcome
eventProbability <- rbind(
  c(0,0,0,1,0,0,0,0),
  c(0,0,0,.5,0,.5,0,0),
  c(.125,.125,.125,.125,.125,.125,.125,.125),
  c(.5,0,0,0,0,0,0,.5),
  c(0,0,0,0,0,1,0,0),
  c(0,0,0,0,0,0,0,1)
)
rownames(eventProbability) <- c("abc","acb","bac","bca","cab","cba")
colnames(eventProbability) <- c("abc","ab","ac","bc","a","b","c","-")

# survivor counts for each outcome
survivors <- c(3,2,2,2,1,1,1,0)

# compute the expected value of each action according to prospect theory
prospects <- matrix( data=0, nrow=6, ncol=4 )
for( reference in 0:3 ) {
  for( event in 1:8 ) {
    for( action in 1:6 ) {

      v <- valueFunction( survivors[event], reference ) * eventProbability[ action, event ]
      prospects[ action, reference+1 ] <- prospects[ action, reference+1 ] + v 
    
    }
  }
}

# convert to a rank ordering
rankedOptions <- matrix( nrow=6, ncol=4 ) 
for( reference in 0:3 ) {
  rankedOptions[ , reference+1 ] <- rank( -prospects[,reference+1])
}