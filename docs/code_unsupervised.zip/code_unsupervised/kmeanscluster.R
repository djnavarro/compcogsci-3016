source('kmeanshelperfns.R');

##### k-means clustering code. As with Dan's, this code is 
# deliberately inefficient, in favour of clarity.
# this code takes some data D with x and y coordinates 
# and the number of clusters to find, k

kmeanscluster <- function( d, k ) {
  
  nn <- length(d$x)   # get the total number of datapoints
  colours <- rep(1,nn)  # set the colours for plotting
  # first step: set each mean randomly to one of the datapoints
  m <- sample(1:nn,k)
  means <- list(x=d$x[m],y=d$y[m]) 
  mprev <- means

  # set initial responsibilities to all one
  # column = datapoint n
  # row = the cluster
  # r(k,n)=1 if it's in that cluster
  rprev <- matrix(0,k,nn)
  rcurr <- matrix(1,k,nn)

  plotdataset( d, d$colours, d$ncat, means, new=TRUE )
  Sys.sleep(0.4)

  # loop until the assignments (responsibilities) have not changed
  while (!all(rcurr==rprev)) {
    rprev <- rcurr
    rcurr <- matrix(0,k,nn)

    # first, do the assignment step
    for( n in 1:nn) {
      ck <- findclosestmean(c(d$x[n],d$y[n]),means)
      rcurr[ck,n] <- 1
    }

    # next, recalculate the means
    for( nk in 1:k) {
      currx <- d$x[rcurr[nk,]==1]
      if (length(currx)!=0) {
        means$x[nk] <- mean(currx)
      }
      curry <- d$y[rcurr[nk,]==1]
      if (length(curry)!=0) {
        means$y[nk] <- mean(curry)
      }
    }
    
    plotdataset( d, rcurr, k, means, new=FALSE )
    Sys.sleep(0.4)
  }

}
