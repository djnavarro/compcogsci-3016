##### calculates the distance between two points X and Y
# assumes each is two-dimensional
# uses formula d(x,y) = 0.5 * sum_i (x_i - y_i)^2 as in lecture 8
getdistance <- function(a,b) {
  distance <- 0.5*sum((a-b)^2) 
  return(distance)
}

##### calculates the distance between two points X and Y
# and divides it by twice the square of the covariance matrix
# uses formula d(x,y) = sum_i (x_i - y_i)^2/(2*sigma_i^2) as in lecture 9
getgaussiandistance <- function(a,b,sigmasq) {
  distance <- sum((a-b)^2/(2*sigmasq))
  return(distance)
}

##### finds the closest mean to D out of the set of means MEANS
findclosestmean <- function(d, means) {
  nummeans <- length(means$x)
  distance <- rep(NA,nummeans)
  for (k in 1:nummeans) {
    distance[k] <- getdistance(d,c(means$x[k],means$y[k]))
  }
  minval <- which(distance %in% sort(distance)[1])
  return(minval)
}


##### plot the dataset given
# D$X and D$Y are x and y coordinates of the data
# D$NCAT is the number of categories, 
# D$NEACH is number of items per category (assumes even)

plotdataset <- function( d, cols, k, means, new=TRUE ) {
  # color vector for plotting. assumes no more than 10 different categories
  colourlist <- rbind(c(0.86,0.08,0.24),c(0,0,0.8),c(0.2,0.98,0.59),c(0.75,0.24,1),c(1,0.93,0.54),
                      c(0.49,0.75,0.93),c(0.8,0.8,0.8),c(1,0.73,0.06),c(1,0.41,0.7),c(0,0.54,0))
  basecolours <- colourlist[1:k,]
  nn <- length(d$x)
  rgbvec <- matrix(0,nn,3)
  for (n in 1:nn) {
    rgbvec[n,] <- colSums(cols[,n]*basecolours)
  }

  # plot the points
  slopx <- max(d$x)/10
  slopy <- max(d$y)/10
  plot(d$x,d$y,type="p",cex=1.5,col="white",pch=16,xlim=c(0,max(d$x)+slopx),ylim=c(0,max(d$y)+slopy))
  if (new) 
    plot(d$x,d$y,type="p",cex=1.5,col=rgb(rgbvec),pch=16,xlim=c(0,max(d$x)+slopx),ylim=c(0,max(d$y)+slopy))
  else {
    points(d$x,d$y,type="p",cex=1.5,col=rgb(rgbvec),pch=16,xlim=c(0,max(d$x)+slopx),ylim=c(0,max(d$y)+slopy))
    points(means$x,means$y,type="p",cex=1.5,col=rgb(basecolours),pch=8,xlim=c(0,max(d$x)+slopx),ylim=c(0,max(d$y)+slopy))    
  }  
}


##### generates a new dataset, and prints it out to FILENAME
# if OPT=1 it generates the dataset randomly
# if OPT=2 it generates a little-and-large dataset
# if OPT=3 it generates a dataset with two elongated clusters
generatedataset <- function( filename, opt ) {
  
  # neach = the number of data points in each category
  neach <- 20
  
  # ncat = the number of total categories
  # stdev = the standard deviation for each category (in x and y)  
  if (opt==1) {
    ncat <- 3
    stdev <- matrix(0.3,ncat,2)
  } else if (opt==2) {
    ncat <- 2
    stdev <- cbind(c(1,0.1),c(1,0.1))
  } else {
    ncat <- 2
    stdev <- cbind(c(0.1,0.1),c(1,1))
  }
  
  # first generate the true means of the categories (between 10 and 90)
  means <- list(x=runif(ncat,0,2),y=runif(ncat,0,2))
 
  # now generate the dataset D
  # x and y correspond to NEACH random points around those means
  # also keeps track of NCAT and NEACH
  d <- list(x=matrix(nrow=neach,ncol=ncat),y=matrix(nrow=neach,ncol=ncat),
            ncat=ncat,neach=neach,colours=matrix(0,nrow=ncat,ncol=ncat*neach))
  for( i in 1:ncat) {
    d$x[,i] <- rnorm(neach,mean=means$x[i],sd=stdev[i,1])
    d$y[,i] <- rnorm(neach,mean=means$y[i],sd=stdev[i,2])
    d$colours[i,(neach*(i-1)+1):(neach*i)] <- rep(1,neach)
  }   
  
  # reshape these into vectors
  d$x <- c(d$x)
  d$y <- c(d$y)
  
  # plot the dataset
  plotdataset( d, d$colours, ncat)
  
  # save the dataset
  save(d,file=paste(filename,'.RData',sep=""))
  return(d)
  
}