source('kmeanshelperfns.R');

##### soft k-means clustering code. This code is 
# deliberately inefficient, in favour of clarity.
# this is just like kmeanscluster.R except the assignment
# of datapoints to clusters is soft (they can be in multiple clusters).
# the BETA parameter governs how "stiff" the assignments are;
# as BETA --> infinity it becomes the same as kmeanscluster.R.
# also, the responsibilities are now an exponential function of 
# the distance rather than the distance itself.
# this code takes some data D with x and y coordinates 
# and the number of clusters to find, k

softkmeanscluster <- function( d, k, beta ) {
  
  nn <- length(d$x)   # get the total number of datapoints
  # first step: set each mean randomly to one of the datapoints
  m <- sample(1:nn,k)
  means <- list(x=d$x[m],y=d$y[m]) 
  mprev <- means
  
  # set initial responsibilities to all one
  # column = datapoint n
  # row = the cluster
  # r(k,n)=1 if it's in that cluster
  rprev <- matrix(0,k,nn)
  rcurr <- matrix(1,k,nn)
  
  plotdataset( d, d$colours, d$ncat, means, new=TRUE )
  Sys.sleep(0.4)
  
  # loop until the assignments (responsibilities) have not changed
  # to prevent really long loops we'll allow a little bit of slop in the
  # assignments
  slop <- 0.05
  while (any(rcurr>rprev+slop) | any(rcurr<rprev-slop)) {
    rprev <- rcurr
    rcurr <- matrix(0,k,nn)
    
    # assignment is inversely proportional to distance from mean
    for( n in 1:nn) {
      for (nk in 1:k) 
        rcurr[nk,n] <- exp(-1*beta*getdistance(c(d$x[n],d$y[n]),
                                          c(means$x[nk],means$y[nk])))
    }
    denom <- colSums(rcurr)
    for (nk in 1:k)
      rcurr[nk,] <- rcurr[nk,]/denom

    # next, recalculate the means. each datapoint contributes proportionally
    # to how much it is in there
    for( nk in 1:k) {
      means$x[nk] <- sum(rcurr[nk,]*d$x)/sum(rcurr[nk,])
      means$y[nk] <- sum(rcurr[nk,]*d$y)/sum(rcurr[nk,])
    }
    
    plotdataset( d, rcurr, k, means, new=FALSE )
    Sys.sleep(0.4)
  }
  
}
